library(tidyverse)
lst <- list(1:10, c(2,4))
lst

lst %>% map(mean)


pacman::p_load(gapminder)
data(gapminder)
gapminder

gapminder_nest <- gapminder %>%
  group_by(country, continent) %>%
  nest()
gapminder_nest

gapminder_nest$data[[1]]

fit_lm <- function(df){
  lm(lifeExp ~ year, data=df)
}

gapminder_nest <- gapminder_nest %>%
  mutate(model = map(data,fit_lm))

gapminder_nest$model[[1]]

gapminder_nest <- gapminder_nest %>%
  mutate(residuals=map(model,broom::augment))

gapminder_nest %>%
  unnest(residuals)


gapminder %>%
  mutate(
    year = year - mean(year)
  ) %>%
  group_by(country, continent
           )%>%
  nest() %>%
  mutate(
    model = map(data, fit_lm),
    coef = map(model, broom::tidy)
  ) %>%
  unnest(coef) %>%
  select(country, continent, term, estimate) %>%
  pivot_wider(names_from = term, values_from = estimate) %>%
  
  rename(intercept = `(Intercept)`, slope = year) %>%
  ggplot(aes(intercept, slope, col= continent, shape = 
               continent)) + 
  geom_point() + 
  viridis::scale_colour_viridis(option="viridis",
                                discrete=TRUE)
