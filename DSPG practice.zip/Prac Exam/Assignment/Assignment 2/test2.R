
pacman::p_load(tidyverse, tidymodels, visdat, naniar, bookdown, yardstick)
theme_set(theme_bw())
if (Sys.info()[["sysname"]]=="Windows") { # if windows
  wdpath <- glue::glue("C:/Users/maxgl/Box Sync/DS_{format(Sys.time(),'%y')}_T{if(as.integer(format(Sys.time(),'%m'))<5){1}else if(as.integer(format(Sys.time(),'%m'))<9){2}else{3}}")
} else if (Sys.info()[["sysname"]]=="Darwin") { # if mac
  wdpath <- glue::glue("~/Box Sync/DS_{format(Sys.time(),'%y')}_T{if(as.integer(format(Sys.time(),'%m'))<5){1}else if(as.integer(format(Sys.time(),'%m'))<9){2}else{3}}")
}


# Load Data

# The data is contained within the file `diamonds.rds`. The data is read in to `R`.

# There are 28,274 rows in the `diamonds` data.

d_data <- readRDS("./data/diamonds.rds")
head(d_data)

# Data Cleaning and Pre-processing

## Remove Missing Prices and Volumes

vis_miss(d_data)
gg_miss_upset(d_data)
# We can see from the plots that some rows are missing from price and volume. 


### Some rows are missing a `price` or `volume`. These rows are removed from the data.

# Using is.na() to remove the rows missing the price and volume values.
d_data <- d_data[!is.na(d_data$price) & !is.na(d_data$volume),]
d_data


# There are now 28,073 rows in the `diamonds` data.

## Derive Cut, Colour, and Clarity

### Cut

##### The *first* character of the variable `c.grade` contains information about the cut of diamonds, according to the following scheme:
  
#  |c.grade|cut    |  
#  |:------|:------|
#  | 1     |premium|
#  | 2     |ideal  |
  
d_data <- d_data %>%
  mutate(
    cut = case_when(
      str_starts(c.grade, "1") ~ "premium", 
      TRUE ~ "ideal"
    ))

d_data

d_data %>% 
  count(cut, name = "count") %>%
  knitr::kable(caption = "Number of diamonds, by cut quality.")

#d_data_new

### We derive `cut` from the first character of `c.grade`. Results are summarised in Table \@ref(tab:diamondcuttab).


### Colour

#### The *second* character of the variable `c.grade` contains information about the colour of diamonds.

d_data <- d_data %>%
  mutate(
    colour = case_when(
      str_detect(c.grade, "T") ~ "T", 
      str_detect(c.grade, "U") ~ "U",
      str_detect(c.grade, "V") ~ "V",
      str_detect(c.grade, "W") ~ "W",
      str_detect(c.grade, "X") ~ "X",
      str_detect(c.grade, "Y") ~ "Y",
      str_detect(c.grade, "Z") ~ "Z"
    ))
d_data

d_data %>% 
  count(colour, name = "count") %>%
  knitr::kable(caption = "Number of diamonds, by colour.")

#d_data_new

# We derive `colour` from the second character of `c.grade`. Results are summarised in Table \@ref(tab:diamondcolourtab).

### Clarity

#The *third* character of the variable `c.grade` contains information about the clarity of diamonds, according to the following scheme:
  
#  |c.grade|clarity|
#  |-------|-------|
#  |0	    |IF     |
#  |1	    |VVS1   |
#  |2	    |VVS2   |
#  |3	    |VS1    |
#  |4	    |VS2    |
#  |5	    |SI1    |
#  |6	    |SI2    |
#  |7	    |I1     |
  
#####  We derive `clarity` from the third character of `c.grade`. Results are summarised in Table \@ref(tab:diamondclaritytab).

d_data <- d_data %>%
  mutate(
    clarity = case_when(
      str_ends(c.grade, "0") ~ "IF", 
      str_ends(c.grade, "1") ~ "VVS1",
      str_ends(c.grade, "2") ~ "VVS2",
      str_ends(c.grade, "3") ~ "VS1",
      str_ends(c.grade, "4") ~ "VS2",
      str_ends(c.grade, "5") ~ "SI1",
      str_ends(c.grade, "6") ~ "SI2",
      str_ends(c.grade, "7") ~ "I1",
    ))

d_data

d_data %>% 
  count(clarity, name = "count") %>%
  knitr::kable(caption = "Number of diamonds, by clarity.")

#d_data


## Select Variables

# We only need the following columns:
  
#- `cut`
#- `price`
#- `volume`

##### All other columns are removed.

d_data <- d_data %>%
  select(cut, price, volume)
d_data

######d_data <- d_data %>%
######  mutate(price = as.numeric(price))

## Convert Cut to Categorical

##### We convert `cut` to a categorical variable.

d_data <- d_data %>% 
  mutate(cut = as.factor(cut)
  )
d_data

# Models
#### We create two separate workflows using `tidymodels`:


#view(d_train)
# Defining the model
log_model <- logistic_reg() %>% set_engine("glm") %>% set_mode("classification")


#### 1. A logistic regression model with `cut` as the response variable and `price` as the predictor.

# Creating recipe
recipe_price <- recipe(cut ~ price, data = d_data) %>%
  step_normalize(all_predictors())


# Price workflow
workflow_price <- workflow() %>%
  add_recipe(recipe_price) %>%
  add_model(log_model)

fit_price <- fit(workflow_price, d_data)
fit_price %>% tidy()

#### 2. A logistic regression model with `cut` as the response variable and `volume` as the predictor.


# Creating recipe
recipe_volume <- recipe(cut ~ volume, data = d_data) %>%
  step_normalize(all_predictors())

# Price workflow
workflow_volume <- workflow() %>%
  add_recipe(recipe_volume) %>%
  add_model(log_model)

fit_volume <- fit(workflow_volume, d_data)
fit_volume %>% tidy()

### Both models are fitted to the `diamonds` data, with ROC curves displayed in Figure \@ref(fig:longleyPlot).

# Predict probabilities on the dataset
pred_price <- predict(fit_price, new_data = d_data, type = "prob") %>% bind_cols(d_data)
pred_volume <- predict(fit_volume, new_data = d_data, type = "prob") %>% bind_cols(d_data)

# Calculate ROC curve data
roc_data_price <- roc_curve(pred_price, truth = cut, .pred_ideal)
roc_data_volume <- roc_curve(pred_volume, truth = cut, .pred_ideal)

# Combine ROC data
roc_data_price <- roc_data_price %>% mutate(model = "Price")
roc_data_volume <- roc_data_volume %>% mutate(model = "Volume")
roc_data_combined <- bind_rows(roc_data_price, roc_data_volume)

# Plot ROC curves with default line thickness
roc_plot <- ggplot(roc_data_combined, aes(x = 1 - specificity, y = sensitivity, color = model)) +
  geom_line() +
  geom_abline(linetype = "dashed", color = "black") +
  labs(title = "ROC Curves for Logistic Regression Models",
       x = "1 - Specificity", y = "Sensitivity") +
  scale_color_manual(values = c("Price" = "red", "Volume" = "cyan")) +
  theme_minimal() +
  theme(legend.position = "bottom")

print(roc_plot)