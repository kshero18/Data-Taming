# Load the dataset
d_data <- readRDS("./data/diamonds.rds")

# Remove rows with missing price or volume
d_data <- d_data[!is.na(d_data$price) & !is.na(d_data$volume),]

# Derive cut, colour, and clarity
d_data <- d_data %>%
  mutate(
    cut = case_when(
      str_starts(c.grade, "1") ~ "premium", 
      str_starts(c.grade, "2") ~ "ideal"
    ),
    colour = case_when(
      str_detect(c.grade, "T") ~ "T", 
      str_detect(c.grade, "U") ~ "U",
      str_detect(c.grade, "V") ~ "V",
      str_detect(c.grade, "W") ~ "W",
      str_detect(c.grade, "X") ~ "X",
      str_detect(c.grade, "Y") ~ "Y",
      str_detect(c.grade, "Z") ~ "Z"
    ),
    clarity = case_when(
      str_ends(c.grade, "0") ~ "IF", 
      str_ends(c.grade, "1") ~ "VVS1",
      str_ends(c.grade, "2") ~ "VVS2",
      str_ends(c.grade, "3") ~ "VS1",
      str_ends(c.grade, "4") ~ "VS2",
      str_ends(c.grade, "5") ~ "SI1",
      str_ends(c.grade, "6") ~ "SI2",
      str_ends(c.grade, "7") ~ "I1"
    )
  )

# Select relevant columns
d_data <- d_data %>% select(cut, price, volume)

# Convert cut to a categorical variable
d_data <- d_data %>% mutate(cut = as.factor(cut))

#d_data <- d_data %>% mutate(price = as.numeric(price))

# Split data into training and testing sets
set.seed(20000)
data_split <- initial_split(d_data, strata = cut)
train_data <- training(data_split)
test_data <- testing(data_split)

# Define the model
log_model <- logistic_reg() %>%
  set_engine("glm") %>%
  set_mode("classification")

# Recipe for price
recipe_price <- recipe(cut ~ price, data = train_data) %>%
  step_normalize(all_predictors())

# Recipe for volume
recipe_volume <- recipe(cut ~ volume, data = train_data) %>%
  step_normalize(all_predictors())

# Workflow for price
workflow_price <- workflow() %>%
  add_recipe(recipe_price) %>%
  add_model(log_model)

# Fit the model on training data
fit_price <- fit(workflow_price, data = train_data)

# Workflow for volume
workflow_volume <- workflow() %>%
  add_recipe(recipe_volume) %>%
  add_model(log_model)

# Fit the model on training data
fit_volume <- fit(workflow_volume, data = train_data)

# Ensure that the factor levels of test_data$cut are correct
test_data$cut <- factor(test_data$cut, levels = c("ideal", "premium"))

# Predict probabilities on the test set
pred_price <- predict(fit_price, test_data, type = "prob")
pred_volume <- predict(fit_volume, test_data, type = "prob")

# Combine the predictions with the test data
test_data <- test_data %>%
  bind_cols(pred_price %>% rename(.pred_price_premium = .pred_premium)) %>%
  bind_cols(pred_volume %>% rename(.pred_volume_premium = .pred_premium))

# Calculate ROC curve data
roc_data_price <- roc_curve(test_data, truth = cut, .pred_price_premium, event_level = "second")
roc_data_volume <- roc_curve(test_data, truth = cut, .pred_volume_premium, event_level = "second")

# Combine ROC data
roc_data_price <- roc_data_price %>% mutate(model = "Price")
roc_data_volume <- roc_data_volume %>% mutate(model = "Volume")
roc_data_combined <- bind_rows(roc_data_price, roc_data_volume)

# Plot ROC curves with default line thickness
roc_plot <- ggplot(roc_data_combined, aes(x = (1 - specificity), y = sensitivity, color = model)) +
  geom_line() +
  geom_abline(linetype = "dashed", color = "black") +
  labs(caption = "ROC Curves for Logistic Regression Models",
       x = "1 - specificity", y = "sensitivity") +
  scale_color_manual(values = c("Price" = "red", "Volume" = "cyan")) +
  theme_minimal() +
  theme(legend.position = "right",
        plot.caption.position = "panel")

print(roc_plot)