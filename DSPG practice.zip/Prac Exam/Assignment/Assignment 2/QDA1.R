# Function to perform QDA
#
# INPUT
# Three vectors:
# x: predictors
# y: classes
# x0: new predictors
#
# OUTPUT
# A vector of predicted classes for x0.

# Criteria 1: get_QDA()
# File contains a function called get_QDA()

get_QDA <- function(x, y, x0) {
  
  # Criteria 2: Correct inputs 
  # Function checks that input vectors are correct type and length.
  
  # Check 1: The 3 inputs are vectors 
  if (!is.vector(x) || !is.vector(y) || !is.vector(x0)) {
    stop("All inputs must be vectors.")
  }
  
  # Check 2: The length of predictors and the classes is equal
  if (length(x) != length(y)) {
    stop("Length of x and y must be equal.")
  }
  
  # Criteria 3: Edge cases
  # Function checks that: y has at least 2 levels; each level has at least 2 observations; and each level has non-zero variance.
  
  # Check 3: Ensure that y has at least two levels
  if (length(unique(y)) < 2) {
    stop("There must be at least two levels in y.")
  }
  
  # Check 4: Ensure that each level has 2 observations
  if (any(table(y) < 2)) {
    stop("Each class in y must have at least two observations.")
  }
  
  # Check 5: Ensuring that the variance is non-zero for each level.
  if (any(sapply(unique(y), function(cl) var(x[y == cl])) == 0)) {
    stop("Each class in y must have non-zero variance.")
  }
  
  # Setting classes for the given y
  classes <- unique(y)
  # Setting the length of the classes
  k <- length(classes)
  
  # Calculating the mean and covariance for each class
  
  # Note that for each unique class label cl in y, the function given below 
  # computes the mean of the subset of x where y is equal to cl. 
  # Similarly for variance. 
  means <- sapply(classes, function(cl) mean(x[y == cl])) 
  covariances <- sapply(classes, function(cl) var(x[y == cl]))
  priors <- table(y) / length(y)
  
  # Function to calculate the QDA discriminant function
  qda_discriminant <- function(x0, mean, covariance, prior) {
    log_prior <- log(prior)
    log_det_cov <- log(covariance)
    mahalanobis_dist <- (x0 - mean)^2 / covariance
    return(log_prior - 0.5 * log_det_cov - 0.5 * mahalanobis_dist)
  }
  
  # Classify each point in x0
  predicted_classes <- sapply(x0, function(x0_i) {
    discriminants <- sapply(1:k, function(i) {
      qda_discriminant(x0_i, means[i], covariances[i], priors[i])
    })
    classes[which.max(discriminants)]
  })
  
  return(predicted_classes)
}

# Example usage
x <- 8:0
y <- rep(LETTERS[26:24], each = 3)
x0 <- c(7, 5)
get_QDA(x = x, y = y, x0 = x0)
# [1] "Z" "Y"


pacman::p_load(tidymodels, parsnip, discrim)

# Prepare the data
data <- tibble(x = x, y = as.factor(rep(LETTERS[26:24], each = 3)))

# Define the QDA model
qda_model <- discrim_quad() %>%
  set_engine("MASS")

# Fit the model
qda_fit <- qda_model %>%
  fit(y ~ x, data = data)

# Make predictions
new_data <- tibble(x = c(7, 5))
predictions <- predict(qda_fit, new_data)

predictions