# Function to perform QDA
#
# INPUT
# Three vectors:
# x: predictors
# y: classes
# x0: new predictors
#
# OUTPUT
# A vector of predicted classes for x0.


library(tibble)
library(dplyr)

# Criteria 1: get_QDA()
# File contains a function called get_QDA()

# Note that when verbose is set to TRUE, the function provides detailed 
# calculations, such as means, variances, priors, and the delta values for each 
# class. When verbose is set to FALSE, the function only returns the predicted 
# class.

get_QDA <- function(x, y, x0, verbose = FALSE) {
  
  # Criteria 2: Correct inputs 
  # Function checks that input vectors are correct type and length.
  
  # Check 1: The 3 inputs are vectors
  if (!is.vector(x) || !is.vector(y) || !is.vector(x0)) {
    stop("All inputs must be vectors.")
  }
  
  # Check 2: The length of predictors and the classes is equal
  if (length(x) != length(y)) {
    stop("Length of x and y must be equal.")
  }
  
  # Criteria 3: Edge cases
  # Function checks that: y has at least 2 levels; each level has at least 2 observations; and each level has non-zero variance.
  
  # Check 3: Ensure that y has at least two levels
  if (length(unique(y)) < 2) {
    stop("There must be at least two classes in y.")
  }
  
  # Check 4: Ensure that each level has 2 observations
  if (any(table(y) < 2)) {
    stop("Each class in y must have at least two observations.")
  }
  
  # Check 5: Ensuring that the variance is non-zero for each level.
  if (any(sapply(unique(y), function(cl) var(x[y == cl])) == 0)) {
    stop("Each class in y must have non-zero variance.")
  }
  
  # Getting estimates
  N <- length(x)
  K <- length(unique(y))
  df <- tibble(x, y)
  
  # Remove missing values
  df <- df %>% drop_na()
  
  # Calculate means, variances, and priors for classes
  class_stats <- df %>%
    group_by(y) %>%
    summarise(
      mu = mean(x),
      sigma2 = var(x),
      pi = n() / N
    )
  
  # Extracting unique parameters specific to the classes
  mu <- class_stats$mu
  sigma2 <- class_stats$sigma2
  pi <- class_stats$pi
  classes <- class_stats$y
  
  # Calculating delta
  
  # Note that as we are dealing with QDA which has multiple predictors we have 
  # created a matrix filled with NA and stores the discriminant values for each 
  # new predictor.
  
  # We know that we are dealing with univariate data as we have vectors as inputs
  # and therefore mu^T * sigma^-1 * mu is same as mu^2 * sigma^-1
  
  # Initialising delta matrix
  delta <- matrix(NA, nrow = length(x0), ncol = K)
  
  # Loop over each class
  for (i in 1:K) {
    sigma_inv <- 1 / sigma2[i]
    sigma_det <- sigma2[i]
    
    for (j in 1:length(x0)) {
      x_new <- x0[j]
      delta[j, i] <- -(1/2) * x_new^2 * sigma_inv + x_new * sigma_inv * mu[i] - 
        (1/2) * mu[i]^2 * sigma_inv - (1/2) * log(sigma_det) + log(pi[i])
    }
  }
  
  # Predict class with maximum delta
  predicted_class <- apply(delta, 1, function(row) classes[which.max(row)])
  
  # If verbose is TRUE then the values are returned
  if (verbose) {
    return(
      list(
        mu = mu,
        sigma2 = sigma2,
        pi = pi,
        delta = delta,
        predicted_class = predicted_class
      )
    )
  }
  
  return(predicted_class)
}

# Example usage of get_QDA
x <- 8:0
y <- rep(LETTERS[26:24], each = 3)
x0 <- c(7, 5)
get_QDA(x = x, y = y, x0 = x0, verbose = TRUE)


##############
# Comparing the above function results with the built in function of QDA 
##############

pacman::p_load(tidymodels, discrim, parsnip)

# Prepare the data
data <- tibble(x = x, y = as.factor(rep(LETTERS[26:24], each = 3)))

# Define the QDA model
qda_model <- discrim_quad() %>%
  set_engine("MASS")

# Fit the model
qda_fit <- qda_model %>%
  fit(y ~ x, data = data)

# Make predictions
new_data <- tibble(x = c(7, 5))
predictions <- predict(qda_fit, new_data)

# Print predictions
print(predictions)
