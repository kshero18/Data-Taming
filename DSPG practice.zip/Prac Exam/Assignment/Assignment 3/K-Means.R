# Function to implement k-means algorithm
#
# INPUT:
# x: numeric vector
# k: number of groups
#
# OUTPUT
# A vector of integer labels indicating group membership.

# get_kmeans(): File contains a function called get_kmeans().

get_kmeans <- function(x, k) {
  
  # Correct inputs: Function checks that inputs are correct type.
  # Ensure inputs are valid
  
  # Checking if x is of numeric type, whether x is a vector or not, checks if the length of x is less than or equal to zero.  
  if (!is.numeric(x) ||!is.vector(x) || length(x) <= 0) stop("x must be a numeric vector")
  
  # Checking if k is numeric type, whether k does not have a length of 1, 
  # if k is less than equal to 0 to ensure that k is a positive number. 
  # Rounding the value of k to nearest integer, to ensure it is positive.
  if (!is.numeric(k) || length(k)!= 1 || k <= 0 || k!= round(k)) stop("k must be a positive integer")
  
  # Check if x has k unique observations
  if (k > length(unique(x))) stop("x must have at least k unique observations")
  
  set.seed(2024)
  # Setting the seed to ensure that the sample is same. 
  
  # We are manually selecting k unique centroids from the data using sampling technique.
  centroids <- sample(unique(x), k, replace = FALSE)
  
  # Initialize labels
  labels <- rep(0, length(x))
  max_iter <- 100
  iter <- 0
  
  # Now we can find the nearest centroid by finding the distance between the
  # each point and each centroid. We also keep a track of the minimum distance. 
  while (iter < max_iter) {
    # Assign points to nearest centroid
    for (j in 1:length(x)) {
      min_dist <- abs(x[j] - centroids[1])
      min_idx <- 1
      for (i in 2:length(centroids)) {
        dist <- abs(x[j] - centroids[i])
        if (dist < min_dist) {
          min_dist <- dist
          min_idx <- i
        }
      }
      labels[j] <- min_idx
    }
    
    print("Index value of labels with minimum distance")
    print(labels)
    
    # Calculate new centroids by computing the mean of the points in each 
    # cluster to find the new centroid
    new_centroids <- numeric(k)
    for (cluster in 1:k) {
      cluster_points <- x[labels == cluster]
      if (length(cluster_points) > 0) {
        new_centroids[cluster] <- sum(cluster_points) / length(cluster_points)
      } else {
        new_centroids[cluster] <- centroids[cluster]  
        # Centroid remains the same if no points are assigned to the cluster.
      }
    }
    
    print("New centroids")
    print(new_centroids)
    
    # Checking if the centroids have changed between iterations, if so then the algo stops
    if (all(new_centroids == centroids)) break
    
    centroids <- new_centroids
    iter <- iter + 1
  }
  
  
  # Ordering 
  
  # Points belonging to the cluster are selected and their mean is calculated.
  cluster_means <- numeric(k)
  for (cluster in 1:k) {
    cluster_points <- x[labels == cluster]
    cluster_means[cluster] <- sum(cluster_points) / length(cluster_points)
  }
  
  print("Cluster means")
  print(cluster_means)
  
  # Ordering the cluster indices from highest to lowest.
  ordered_indices <- order(cluster_means, decreasing = TRUE)
  
  print("Ordered indices in decending order")
  print(ordered_indices)
  
  # Re-label the groups based on the ordering, the highest mean gets label 1, 
  # The next one gets 2 and so on till the ordered vector exhausts.
  final_labels <- labels
  for (i in 1:k) {
    final_labels[labels == ordered_indices[i]] <- i
  }
  
  return(final_labels)
}

# Example usage
x <- rep(2:4, each = 3)
x <- c(2,2,3,3,4,4)
x <- c(2,3,4,2,3,4)
res <- get_kmeans(x, 3)
print("get_means function")
res

print("In-buit Kmeans")
kmeans(x, 3)
