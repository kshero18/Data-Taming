# get_ROC function

# Function to return ROC
#
# INPUT
# Two vectors:

# obs: a factor with two levels, "A" and "B"
# A: the predicted probability that each observation
# is "A"
#
# OUTPUT
# A tibble with 3 columns: threshold, specificity, and
# sensitivity.

library(tibble)
library(dplyr)

get_ROC <- function(obs, A) {

  # Checking if obs is factor and A is numeric; if not then it returns an 
  # error statement.
  if (!is.factor(obs) || !is.numeric(A)) {
    stop("obs must be a factor and A must be numeric.")
  }
  
  # Checking if obs and A are of same length; if not then it returns an 
  # error statement.
  if (length(obs) != length(A)) {
    stop("The 'obs' and 'A' arguments must have the same length.")
  }
  
  #Creating a tibble for the obs and A vectors
  roc_tibble <- tibble(obs, A) 
  
  #Ordering the pred values in ascending order to ensure the expected output
  roc_tibble <- roc_tibble %>% arrange(A)
  
  #Adding extreme values to cover all the cases
  threshold <- unique(c(-Inf, roc_tibble$A, Inf)) 
  
  # Factoring the obs values in order to ensure that 'A' is considered as positive
  # and 'B' is considered as negative
  obs <- factor(roc_tibble$obs, levels = c('A', 'B'))
  
  # Creating sensi and speci vectors to store the sensitivity and specificity of 
  # different threshold values. 
  sensi <- numeric(length(threshold))
  speci <- numeric(length(threshold))
  
  # Using loop to follow through the different threshold values and calculate 
  # sensitivity and specificity
  for (i in 1:length(threshold)) {
    
    # Putting each threshold value in thres
    thres <- threshold[i]
    
    # If predicted probability is greater than or equal to thres and observed 
    # value is 'A' then its counted as True positive value 
    TP <- sum(roc_tibble$A >= thres & roc_tibble$obs == 'A')
    
    # If predicted probability is less than thres and observed value is 'A' then
    # its counted as False negative value
    FN <- sum(roc_tibble$A < thres & roc_tibble$obs == 'A')
    
    # If predicted probability is less than thres and observed value is 'B' then 
    # its counted as True negative value
    TN <- sum(roc_tibble$A < thres & roc_tibble$obs == 'B')
    
    # If predicted probability is greater than or equal to thres and observed 
    # value is 'B' then its counted as False positive value
    FP <- sum(roc_tibble$A >= thres & roc_tibble$obs == 'B')
    
    # Calculating sensitivity 
    sensi[i] <- TP / (TP + FN)
    
    # Calculating specificity
    speci[i] <- TN / (TN + FP)
  }
  
  # Creating tibble with 3 columns i.e. threshold, specificity and sensitivity
  roc_res <- tibble(
    threshold = threshold,
    specificity = speci,
    sensitivity = sensi
  )
  return(roc_res)
}

# Using the given example to check the correctness of the created function.
df <- tibble(
  obs = rep(factor(c("A","B")), each = 2),
  A = rep(c(0.8,0.2), each = 2)
)
get_ROC(df$obs, df$A)

# Checking if the result aligns with the result from the function.
yardstick::roc_curve(df,obs, A)
