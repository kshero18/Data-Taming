pacman::p_load(tidyverse, tidymodels, visdat, naniar, bookdown, 
               yardstick, plotly, testrecipes)
d_data <- readRDS("./sample_ex.rds")
d_data

ggplot(d_data, aes(Y)) + 
  geom_histogram()

skimr::skim(d_data)

d_data <- d_data %>% 
  mutate(lod_Y = log(Y))
d_data

mean(d_data$X2)

skimr::skim(d_data)

mean(d_data$lod_Y)

d_data %>% filter(X2 < -20)

d_data$X2 <- ifelse(d_data$X2 < -10, NA, d_data$X2)

mean(d_data)
