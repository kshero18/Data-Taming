get_mean <- function(x){
  total <- 0
  n <- length(x)
  for(i in 1:n){
    total <- total + x[i]
  }
  return (total/n)
}

get_mean(1:10)

