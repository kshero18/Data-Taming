install.packages("recipes", dependencies = TRUE)
update.packages(ask = FALSE)
install.packages("workflows", dependencies = TRUE)

library(workflows)
data(mpg, package = "ggplot2")
library(recipes)
mpg

mpg_recipe <- recipe(cty ~ displ + drv, data = mpg)
mpg_recipe

mpg_recipe <- mpg_recipe %>%
  step_center(all_numeric_predictors()) %>%
  step_scale(all_numeric_predictors())
mpg_recipe

mpg_recipe %>% prep() %>% tidy(n=1)

mpg_recipe <- mpg_recipe %>%
  step_dummy(all_nominal_predictors())
mpg_recipe

mpg_recipe %>% prep() %>% tidy()

mpg_recipe %>% prep() %>% tidy(n=3)

mpg_recipe <- mpg_recipe %>%
  step_interact(terms = ~starts_with("drv"):displ)
mpg_recipe

mpg_recipe %>% prep() %>% tidy(n=4)

mpg_wf <- workflow()
mpg_wf <- mpg_wf %>%
  add_recipe(mpg_recipe)
mpg_wf

mpg_recipe %>%
  prep() %>%
  bake(new_data = NULL)

new_data <- tibble(displ = c(1,2),
                   drv = c("f","r"))
new_data
mpg_recipe %>% prep() %>% bake(new_data = new_data)

m <- mean(new_data$displ)
std <- sd(new_data$displ)
centre <- new_data$displ - m
sc <- centre/std
sc
# Create a recipe for centering and scaling
new_data_recipe <- recipe(~ displ, data = new_data) %>%
  step_center(displ) %>%
  step_scale(displ)

# Prepare and apply the recipe to the new data
new_data_prep <- prep(new_data_recipe, training = new_data)
transformed_data <- bake(new_data_prep, new_data = NULL)

# Print the transformed data to get the centered and scaled displacement
transformed_data