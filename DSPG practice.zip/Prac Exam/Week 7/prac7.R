# Prac 7

pacman::p_load(tidyverse, tidymodels, yardstick, ggplot2)
data("penguins", package = "palmerpenguins")
penguins <- penguins %>% na.omit()

# model 1

model1 <- linear_reg() %>% 
  set_mode("regression") %>%
  set_engine("lm")

recipe1 <- recipe(flipper_length_mm ~ body_mass_g, data = penguins)

wf1 <- workflow() %>%
  add_model(model1)%>%
  add_recipe(recipe1)
wf1


# model 2

model2 <- logistic_reg() %>% 
  set_mode("classification") %>%
  set_engine("glm")

recipe2 <- recipe(sex ~ body_mass_g, data = penguins)

wf2 <- workflow() %>%
  add_model(model2)%>%
  add_recipe(recipe2)
wf2

penguins_fit1 <- wf1 %>% fit(penguins)
penguins_fit2 <- wf2 %>% fit(penguins)

penguins_fit1
penguins_fit2

penguins_pred <- penguins %>%
  bind_cols(predict(penguins_fit1, penguins),
            predict(penguins_fit2, penguins),
            predict(penguins_fit2, penguins, type="prob")) %>%
  select(sex, flipper_length_mm, starts_with(".pred"))
penguins_pred
#view(penguins_pred)

penguins_pred %>%
  rmse(truth = flipper_length_mm,
       estimate = .pred)
rsq <- penguins_pred %>%
  rsq(truth = flipper_length_mm,
      estimate = .pred)
rsq

quantitative_metrics <- metric_set(rmse, mae)
penguins_pred %>%
  quantitative_metrics(truth = flipper_length_mm,
                       estimate = .pred)

# hard classification

penguins_pred %>%
  conf_mat(truth = sex,
           estimate = .pred_class)

penguins_pred %>%
  sens(truth = sex,
       estimate = .pred_class)

penguins_pred %>%
  spec(truth = sex,
       estimate = .pred_class)

penguins_pred %>%
  precision(truth = sex,
       estimate = .pred_class)

penguins_pred %>%
  recall(truth = sex,
       estimate = .pred_class)

penguins_pred %>%
  roc_curve(truth = sex, .pred_female) %>%
  autoplot()

penguins_pred %>%
  roc_auc( truth = sex, .pred_female)
