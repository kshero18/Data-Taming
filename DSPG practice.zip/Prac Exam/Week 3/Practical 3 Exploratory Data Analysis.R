pacman::p_load(tidyverse)
install.packages("viridis")
library(viridis)
data(mpg, package = "ggplot2")

mpg <- mpg %>%
  select(cty, displ, drv)
mpg

skimr::skim_without_charts(mpg)

mpg <- mpg %>% 
  mutate(drv = factor(drv))

skimr::skim_without_charts(mpg)

mpg %>% 
  ggplot(aes(cty)) + 
  geom_histogram(col="black", fill="#9f4fff")

mpg %>%
  ggplot(aes(displ)) + 
  geom_histogram(col="black", fill="#9f5fff")

skimr::skim(mpg)

p <-mpg %>% 
  ggplot(aes(drv, fill=drv)) +
  geom_bar(col = "black") +
  labs(
    title = "Bar Chart of Drive for the mpg Dataset.",
    x = "Drive")

mpg %>% 
  ggplot(aes(x=displ, y=cty)) +
  geom_point() + 
  labs(x= "Displacement (litres)",
       y = "City Fuel Efficiency (miles per gallon)") +
  ggtitle(
    "Scatterplot of City Fuel Efficiency Against Displacement\nfor the mpg Dataset"
  )+
  geom_smooth()

mpg %>%
  ggplot(aes(x=drv, y=cty, fill=drv))+
  geom_boxplot()+
  labs(x = "Drive",
       y = "City Fuel Efficiency (miles per gallon)")
