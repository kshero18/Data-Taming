pacman::p_load(tidyverse, tidymodels, discrim, naivebayes, LiblineaR, magrittr)
star_trek <- read_rds("./star_trek.rds")
