# Load the Data and Libraries

pacman::p_load(tidyverse, tidymodels, pROC, ggplot2)
data("penguins", package = "palmerpenguins")

# Split the Data
set.seed(2024)
penguin_split <- initial_split(penguins)
penguin_split

penguins_train <- training(penguin_split)
penguins_test <- testing(penguin_split)

penguin_CV <- vfold_cv(penguins_train)
penguin_CV

# Fit the Models and Measure Performance Models

linear_model <- linear_reg() %>%
  set_engine("lm")

penguin_linear_workflow <- workflow() %>%
  add_model(linear_model) %>%
  add_formula(bill_length_mm ~ body_mass_g)

#######

logistic_model <- logistic_reg() %>%
  set_engine("glm")

penguin_logistic_workflow <- workflow() %>%
  add_model(logistic_model) %>%
  add_formula(sex ~ body_mass_g)

# CV Folds

penguin_linear_resamples <- fit_resamples(penguin_linear_workflow,
                                          resamples = penguin_CV,
                                          control = control_resamples(
                                            save_pred = TRUE))
penguin_linear_resamples


penguin_logistic_resamples <- fit_resamples(penguin_logistic_workflow,
                                            resamples = penguin_CV,
                                            control = control_resamples(
                                              save_pred = TRUE))
penguin_logistic_resamples


# Metrics

penguin_linear_resamples %>% unnest(.metrics)
penguin_linear_resamples %>% collect_metrics()

penguin_logistic_resamples %>% unnest(.metrics)
penguin_logistic_resamples %>% collect_metrics()

penguin_logistic_resamples %>%
  collect_predictions() %>%
  group_by(id) %>%
  roc_curve(truth = sex, .pred_female) %>%
  autoplot() +
  viridis::scale_color_viridis(option = "viridis", end = .8, discrete = TRUE)

# Measuring Model Performance Using the Testing Set

penguin_linear_workflow %>% 
  last_fit(penguin_split) %>%
  collect_metrics()

penguin_logistic_workflow %>%
  last_fit(penguin_split) %>%
  collect_metrics()

